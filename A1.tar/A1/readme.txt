Michal Chorobik
0937145
Assignment 1

The first program runs by itslef automatically. It prints onto the screen every possible combination of the letters c,a,r,b,o and n  while not reusing the letter more than once each time
sample(of just a part of the accual output):
ncraob
ncrabo
ncbroa
ncbrao
ncbora
ncboar
ncbaor
ncbaro
ncobra
ncobar
ncorba
ncorab
ncoarb
ncoabr
ncabor
ncabro
ncaobr
ncaorb
ncarob
ncarbo

The second program asks the user the user to input two positive numbers that are then put into the Ackermann�s function. The function gives us an answer to that function.
sample:
input: 3 and 4
output: 
answer is 125.000000
 
The third program is a program that asks the user to enter two positive numbers. The first number is the number that the program will get the square root of and the second number is how accurate the answer will be. Then the program will print onto the screen the time in milliseconds that it took the recursive and the non-recursive functions to calculate the answer
sample:

input: 65 and 0.0002

output: 
your answer is 8.062259
Operation took 1 milliseconds for the recursive function
Operation took 0 milliseconds for the non-recursive function
